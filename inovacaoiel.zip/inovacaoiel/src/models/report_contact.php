<?php

class ReportContact extends Model {
}
