<?php

class QuestionResponse extends Model {
}
