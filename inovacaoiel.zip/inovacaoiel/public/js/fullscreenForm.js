/**
 * fullscreenForm.js v1.0.0
 * http://www.codrops.com
 *
 * Licensed under the MIT license.
 * http://www.opensource.org/licenses/mit-license.php
 *
 * Copyright 2014, Codrops
 * http://www.codrops.com
 */
;( function( window ) {

	'use strict';

	var support = { animations : Modernizr.cssanimations },
		animEndEventNames = { 'WebkitAnimation' : 'webkitAnimationEnd', 'OAnimation' : 'oAnimationEnd', 'msAnimation' : 'MSAnimationEnd', 'animation' : 'animationend' },
		// animation end event name
		animEndEventName = animEndEventNames[ Modernizr.prefixed( 'animation' ) ];

	/**
	 * extend obj function
	 */
	function extend( a, b ) {
		for( var key in b ) {
			if( b.hasOwnProperty( key ) ) {
				a[key] = b[key];
			}
		}
		return a;
	}

	/**
	 * createElement function
	 * creates an element with tag = tag, className = opt.cName, innerHTML = opt.inner and appends it to opt.appendTo
	 */
	function createElement( tag, opt ) {
		var el = document.createElement( tag )
		if( opt ) {
			if( opt.cName ) {
				el.className = opt.cName;
			}
			if( opt.inner ) {
				el.innerHTML = opt.inner;
			}
			if( opt.appendTo ) {
				opt.appendTo.appendChild( el );
			}
		}
		return el;
	}

	/**
	 * FForm function
	 */
	function FForm( el, options ) {
		this.el = el;
		this.options = extend( {}, this.options );
  		extend( this.options, options );
  		this._init();
	}

	/**
	 * FForm options
	 */
	FForm.prototype.options = {
		// show progress bar
		ctrlProgress : true,
		// show navigation dots
		ctrlNavDots : true,
		// show [current field]/[total fields] status
		ctrlNavPosition : true,
		// reached the review and submit step
		onReview : function() { return false; }
	};

	/**
	 * init function
	 * initialize and cache some vars
	 */
	FForm.prototype._init = function() {
		// the form element
		this.formEl = this.el.querySelector( 'form' );

		// list of fields
		this.fieldsList = this.formEl.querySelector( 'ol.fs-fields' );

		// current field position
		this.current = 0;
		this.currentQuestion = 1;

		// all fields
		this.fields = [].slice.call( this.fieldsList.children );

		// total fields
		this.fieldsCount = this.fields.length;

		// show first field
		classie.add( this.fields[ this.current ], 'fs-current' );

		// create/add controls
		this._addControls();

		// create/add messages
		this._addErrorMsg();

		// init events
		this._initEvents();
	};

	/**
	 * addControls function
	 * create and insert the structure for the controls
	 */
	FForm.prototype._addControls = function() {
		// main controls wrapper
		this.ctrls = createElement( 'div', { cName : 'fs-controls', appendTo : this.el } );

		// continue button (jump to next field)
		this.ctrlContinue = createElement( 'button', { cName : 'fs-continue', inner : 'CONTINUAR', appendTo : this.ctrls } );
		this.ctrlBack = createElement( 'button', { cName : 'fs-back', inner : 'VOLTAR', appendTo : this.ctrls } );

		// navigation dots
		if( this.options.ctrlNavDots ) {
			this.ctrlNav = createElement( 'nav', { cName : 'fs-nav-dots', appendTo : this.ctrls } );
			var dots = '';
			for( var i = 0; i < this.fieldsCount; ++i ) {
				dots += i === this.current ? '<button class="fs-dot-current"></button>' : '<button disabled></button>';
			}
			this.ctrlNav.innerHTML = dots;
			this._showCtrl( this.ctrlNav );
			this.ctrlNavDots = [].slice.call( this.ctrlNav.children );
		}

		// field number status
		if( this.options.ctrlNavPosition ) {
			this.ctrlFldStatus = createElement( 'span', { cName : 'fs-numbers', appendTo : this.ctrls } );

			// current field placeholder
			this.ctrlFldStatusCurr = createElement( 'span', { cName : 'fs-number-current', inner : Number( this.current + 1 ) } );
			this.ctrlFldStatus.appendChild( this.ctrlFldStatusCurr );

			// total fields placeholder
			this.ctrlFldStatusTotal = createElement( 'span', { cName : 'fs-number-total', inner : this.fieldsCount } );
			this.ctrlFldStatus.appendChild( this.ctrlFldStatusTotal );
			this._showCtrl( this.ctrlFldStatus );
		}

		// progress bar
		if( this.options.ctrlProgress ) {
			this.ctrlProgress = createElement( 'div', { cName : 'fs-progress', appendTo : this.ctrls } );
			this._showCtrl( this.ctrlProgress );
		}
	}

	/**
	 * addErrorMsg function
	 * create and insert the structure for the error message
	 */
	FForm.prototype._addErrorMsg = function() {
		// error message
		this.msgError = createElement( 'span', { cName : 'fs-message-error', appendTo : this.el } );
	}

	/**
	 * init events
	 */
	FForm.prototype._initEvents = function() {
		var self = this;

		// show last field
		this.ctrlBack.addEventListener( 'click', function() {
			self._showField(self.current - 1);
		} );

		// show next field
		this.ctrlContinue.addEventListener( 'click', function() {
			self._nextField();
		} );

		// navigation dots
		if( this.options.ctrlNavDots ) {
			this.ctrlNavDots.forEach( function( dot, pos ) {
				dot.addEventListener( 'click', function() {
					self._showField( pos );
				} );
			} );
		}

		// jump to next field without clicking the continue button (for fields/list items with the attribute "data-input-trigger")
		this.fields.forEach( function( fld ) {
			if( fld.hasAttribute( 'data-input-trigger' ) ) {
				var input = fld.querySelector( 'input[type="radio"]' ) || fld.querySelector( 'select' ) || fld.querySelector('a.fs-button');
				if( !input ) return;

				switch( input.tagName.toLowerCase() ) {
					case 'select' :
						input.addEventListener( 'change', function() { self._nextField(); } );
						break;

					case 'a' :
						input.addEventListener( 'click', function() { self._nextField(); } );
						break;

					case 'input' :
						[].slice.call( fld.querySelectorAll( 'input[type="radio"]' ) ).forEach( function( inp ) {
							inp.addEventListener( 'change', function(ev) {
								ev.preventDefault();
								if (classie.has(inp, 'sexy-radio') && document.createElement('svg').getAttributeNS) {
									self._draw(inp, function() {
										self._nextField();
									});
								} else {
									self._nextField();
								};
							});
						});
						break;
				}
			}
		} );

		// keyboard navigation events - jump to next field when pressing enter
		document.addEventListener( 'keydown', function( ev ) {
			if( !self.isLastStep && ev.target.tagName.toLowerCase() !== 'textarea' ) {
				var keyCode = ev.keyCode || ev.which;
				if( keyCode === 13 ) {
					ev.preventDefault();
					self._nextField();
				}
			}
		} );
	};

	/**
	 * nextField function
	 * jumps to the next field
	 */
	FForm.prototype._nextField = function( backto ) {
		if( this.isLastStep || (backto === undefined && !this._validate()) || this.isAnimating ) {
			return false;
		}
		this.isAnimating = true;

		// check if on last step
		this.isLastStep = this.current === this.fieldsCount - 1 && backto === undefined ? true : false;

		// clear any previous error messages
		this._clearError();

		// current field
		var currentFld = this.fields[ this.current ];

		// save the navigation direction
		this.navdir = backto !== undefined ? backto < this.current ? 'prev' : 'next' : 'next';

		// update current field
		this.current = backto !== undefined ? backto : this.current + 1;

		if( backto === undefined ) {
			// update progress bar (unless we navigate backwards)
			this._progress();

			// save farthest position so far
			this.farthest = this.current;
		}

		// add class "fs-display-next" or "fs-display-prev" to the list of fields
		classie.add( this.fieldsList, 'fs-display-' + this.navdir );

		// remove class "fs-current" from current field and add it to the next one
		// also add class "fs-show" to the next field and the class "fs-hide" to the current one
		classie.remove( currentFld, 'fs-current' );
		classie.add( currentFld, 'fs-hide' );

		if (currentFld.hasAttribute('data-question')) {
			var timestamp = Math.floor(Date.now() / 1000);
			var timeToAnswer = (timestamp - this.questionResponseTime);
			mixpanel.track("respondeu-questao", {questao: this.currentQuestion, tempo: timeToAnswer});
			this.currentQuestion++;
		}

		if (currentFld.hasAttribute('data-company-size-question')) {
			var fields = currentFld.querySelectorAll('input');
			for (var i = 0; i < fields.length; i++) {
				var input = fields[i];
				if (input.checked) {
					mixpanel.track('respondeu-porte', { porte: i });
					break;
				}
			}
		}

		if (currentFld.hasAttribute('data-state-question')) {
			var stateField = currentFld.querySelector('select');
			var cityField = currentFld.querySelector('input');
			mixpanel.track('respondeu-estado', { estado: stateField.value, cidade: stateField.value });
		}

		if( !this.isLastStep ) {
			// update nav
			this._updateNav();

			// change the current field number/status
			this._updateFieldNumber();

			var nextField = this.fields[ this.current ];
			classie.add( nextField, 'fs-current' );
			classie.add( nextField, 'fs-show' );

			if (nextField.hasAttribute( 'data-hide-last-button' )) {
				classie.remove(this.ctrlBack, 'fs-show');
				classie.add(this.ctrlBack, 'fs-hide');
			} else {
				classie.add(this.ctrlBack, 'fs-show');
				classie.remove(this.ctrlBack, 'fs-hide');
			}

			if (nextField.hasAttribute( 'data-hide-next-button' )) {
				classie.remove(this.ctrlContinue, 'fs-show');
				classie.add(this.ctrlContinue, 'fs-hide');
			} else {
				classie.add(this.ctrlContinue, 'fs-show');
				classie.remove(this.ctrlContinue, 'fs-hide');
			}

			if (nextField.hasAttribute('data-register-event')) {
				var event = nextField.getAttribute('data-register-event');
				mixpanel.track(event);
			}

			if (nextField.hasAttribute('data-question')) {
				this.questionResponseTime = Math.floor(Date.now() / 1000);
			}
		}

		// after animation ends remove added classes from fields
		var self = this,
			onEndAnimationFn = function( ev ) {
				if( support.animations ) {
					this.removeEventListener( animEndEventName, onEndAnimationFn );
				}

				classie.remove( self.fieldsList, 'fs-display-' + self.navdir );
				classie.remove( currentFld, 'fs-hide' );

				if( self.isLastStep ) {
					// show the complete form and hide the controls
					self._hideCtrl( self.ctrlNav );
					self._hideCtrl( self.ctrlProgress );
					self._hideCtrl( self.ctrlContinue );
					self._hideCtrl( self.ctrlFldStatus );
					// replace class fs-form-full with fs-form-overview
					//classie.remove( self.formEl, 'fs-form-full' );
					//classie.add( self.formEl, 'fs-form-overview' );
					//classie.add( self.formEl, 'fs-show' );
					// callback
					self.options.onReview();
				}
				else {
					var pageOffset = window.pageYOffset;
					var el = document.querySelector('.fs-current .field-title');

					if (pageOffset > el.getBoundingClientRect().top) {
						jump(el, {duration: 400})
					}
					classie.remove( nextField, 'fs-show' );

					if( self.options.ctrlNavPosition ) {
						self.ctrlFldStatusCurr.innerHTML = self.ctrlFldStatusNew.innerHTML;
						self.ctrlFldStatus.removeChild( self.ctrlFldStatusNew );
						classie.remove( self.ctrlFldStatus, 'fs-show-' + self.navdir );
					}

					var nextTextField = nextField.querySelectorAll('input[type=text]')[0];
					var nextEmailField = nextField.querySelectorAll('input[type=email]')[0];
					if (nextTextField) {
						nextTextField.focus();
					} else if (nextEmailField) {
						nextEmailField.focus();
					}
				}
				self.isAnimating = false;
			};

		if( support.animations ) {
			if( this.navdir === 'next' ) {
				if( this.isLastStep ) {
					currentFld.querySelector( '.fs-anim-upper' ).addEventListener( animEndEventName, onEndAnimationFn );
				}
				else {
					nextField.querySelector( '.fs-anim-lower' ).addEventListener( animEndEventName, onEndAnimationFn );
				}
			}
			else {
				nextField.querySelector( '.fs-anim-upper' ).addEventListener( animEndEventName, onEndAnimationFn );
			}
		}
		else {
			onEndAnimationFn();
		}
	}

	/**
	 * showField function
	 * jumps to the field at position pos
	 */
	FForm.prototype._showField = function( pos ) {
		if( pos === this.current || pos < 0 || pos > this.fieldsCount - 1 ) {
			return false;
		}
		this._nextField( pos );
	}

	/**
	 * updateFieldNumber function
	 * changes the current field number
	 */
	FForm.prototype._updateFieldNumber = function() {
		if( this.options.ctrlNavPosition ) {
			// first, create next field number placeholder
			this.ctrlFldStatusNew = document.createElement( 'span' );
			this.ctrlFldStatusNew.className = 'fs-number-new';
			this.ctrlFldStatusNew.innerHTML = Number( this.current + 1 );

			// insert it in the DOM
			this.ctrlFldStatus.appendChild( this.ctrlFldStatusNew );

			// add class "fs-show-next" or "fs-show-prev" depending on the navigation direction
			var self = this;
			setTimeout( function() {
				classie.add( self.ctrlFldStatus, self.navdir === 'next' ? 'fs-show-next' : 'fs-show-prev' );
			}, 25 );
		}
	}

	/**
	 * progress function
	 * updates the progress bar by setting its width
	 */
	FForm.prototype._progress = function() {
		if( this.options.ctrlProgress ) {
			this.ctrlProgress.style.width = this.current * ( 100 / this.fieldsCount ) + '%';
		}
	}

	/**
	 * updateNav function
	 * updates the navigation dots
	 */
	FForm.prototype._updateNav = function() {
		if( this.options.ctrlNavDots ) {
			classie.remove( this.ctrlNav.querySelector( 'button.fs-dot-current' ), 'fs-dot-current' );
			classie.add( this.ctrlNavDots[ this.current ], 'fs-dot-current' );
			this.ctrlNavDots[ this.current ].disabled = false;
		}
	}

	/**
	 * showCtrl function
	 * shows a control
	 */
	FForm.prototype._showCtrl = function( ctrl ) {
		classie.add( ctrl, 'fs-show' );
	}

	/**
	 * hideCtrl function
	 * hides a control
	 */
	FForm.prototype._hideCtrl = function( ctrl ) {
		if (ctrl == null) {
			return;
		}

		classie.remove( ctrl, 'fs-show' );
	}

	// TODO: this is a very basic validation function. Only checks for required fields..
	FForm.prototype._validate = function() {
		var fld = this.fields[ this.current ],
			inputs = fld.querySelectorAll( 'input[required]' ) ||
							 fld.querySelectorAll( 'textarea[required]' ) ||
							 fld.querySelectorAll( 'select[required]' ),
			error;

		if( !inputs || !inputs.length ) return true;

		for (var i = 0 ; i < inputs.length ; i++) {
			var input = inputs[i];

			switch( input.tagName.toLowerCase() ) {
				case 'input' :
					if( input.type === 'radio' || input.type === 'checkbox' ) {
						var checked = 0;
						[].slice.call( fld.querySelectorAll( 'input[type="' + input.type + '"]' ) ).forEach( function( inp ) {
							if( inp.checked ) {
								++checked;
							}
						} );
						if( !checked ) {
							error = 'NOVAL';
						}
					}
					else if (input.type === 'email') {
						var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    				var filled = re.test(input.value);

    				if (!filled) {
    					error = 'INVALIDEMAIL'
    				}
					}
					else if( input.value === '' ) {
						error = 'NOVAL';
					}
					break;

				case 'select' :
					// assuming here '' or '-1' only
					if( input.value === '' || input.value === '-1' ) {
						error = 'NOVAL';
					}
					break;

				case 'textarea' :
					if( input.value === '' ) {
						error = 'NOVAL';
					}
					break;
			}
		}

		if( error != undefined ) {
			this._showError( error );
			return false;
		}

		return true;
	}

	// TODO
	FForm.prototype._showError = function( err ) {
		var message = '';
		switch( err ) {
			case 'NOVAL' :
				message = 'Por favor preencha o campo antes de prosseguir';
				break;
			case 'INVALIDEMAIL' :
				message = 'Por favor informe um email válido';
				break;
			// ...
		};
		this.msgError.innerHTML = message;
		this._showCtrl( this.msgError );
	}

	// clears/hides the current error message
	FForm.prototype._clearError = function() {
		this._hideCtrl( this.msgError );
	}

	FForm.prototype._draw = function(el, callback) {
		this._resetRadio(el);

		var paths = [], svg = el.parentNode.querySelector('label svg');

		paths.push(document.createElementNS('http://www.w3.org/2000/svg', 'path'));

		for (var i = 0, len = paths.length; i < len; ++i) {
			var path = paths[i];
			svg.appendChild(path);

			path.setAttributeNS(null, 'd', pathDef[i]);

			var length = path.getTotalLength();
			path.style.strokeDasharray = length + ' ' + length;
			path.style.strokeDashoffset = (i === 0 ? (Math.floor(length) - 1) : length);
			path.getBoundingClientRect();
			path.style.transition = path.style.WebkitTransition = path.style.MozTransition  = 'stroke-dashoffset ' + animDef.speed + 's ' + animDef.easing + ' ' + i * animDef.speed + 's';
			path.style.strokeDashoffset = '0';
		}

		setTimeout(function() {
			callback();
		}, paths.length * animDef.speed * 1000);
	}

	FForm.prototype._resetRadio = function resetRadio( el ) {
		Array.prototype.slice.call( document.querySelectorAll( 'input[type="radio"][name="' + el.getAttribute( 'name' ) + '"]' ) ).forEach( function( el ) {
			var path = el.parentNode.querySelector( 'label svg > path' );
			if( path ) {
				path.parentNode.removeChild( path );
			}
		});
	}

	// add to global namespace
	window.FForm = FForm;

	function createSVGEl( def ) {
		var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
		svg.setAttributeNS( null, 'viewBox', '0 0 100 100' );
		svg.setAttribute( 'xmlns', 'http://www.w3.org/2000/svg' );
		return svg;
	}

	if (document.createElement('svg').getAttributeNS) {
		var radiobxsFill = Array.prototype.slice.call( document.querySelectorAll( 'form.ac-fill input[type="radio"].sexy-radio' ) ),

			pathDef = ['M15.833,24.334c2.179-0.443,4.766-3.995,6.545-5.359 c1.76-1.35,4.144-3.732,6.256-4.339c-3.983,3.844-6.504,9.556-10.047,13.827c-2.325,2.802-5.387,6.153-6.068,9.866 c2.081-0.474,4.484-2.502,6.425-3.488c5.708-2.897,11.316-6.804,16.608-10.418c4.812-3.287,11.13-7.53,13.935-12.905 c-0.759,3.059-3.364,6.421-4.943,9.203c-2.728,4.806-6.064,8.417-9.781,12.446c-6.895,7.477-15.107,14.109-20.779,22.608 c3.515-0.784,7.103-2.996,10.263-4.628c6.455-3.335,12.235-8.381,17.684-13.15c5.495-4.81,10.848-9.68,15.866-14.988 c1.905-2.016,4.178-4.42,5.556-6.838c0.051,1.256-0.604,2.542-1.03,3.672c-1.424,3.767-3.011,7.432-4.723,11.076 c-2.772,5.904-6.312,11.342-9.921,16.763c-3.167,4.757-7.082,8.94-10.854,13.205c-2.456,2.777-4.876,5.977-7.627,8.448 c9.341-7.52,18.965-14.629,27.924-22.656c4.995-4.474,9.557-9.075,13.586-14.446c1.443-1.924,2.427-4.939,3.74-6.56 c-0.446,3.322-2.183,6.878-3.312,10.032c-2.261,6.309-5.352,12.53-8.418,18.482c-3.46,6.719-8.134,12.698-11.954,19.203 c-0.725,1.234-1.833,2.451-2.265,3.77c2.347-0.48,4.812-3.199,7.028-4.286c4.144-2.033,7.787-4.938,11.184-8.072 c3.142-2.9,5.344-6.758,7.925-10.141c1.483-1.944,3.306-4.056,4.341-6.283c0.041,1.102-0.507,2.345-0.876,3.388 c-1.456,4.114-3.369,8.184-5.059,12.212c-1.503,3.583-3.421,7.001-5.277,10.411c-0.967,1.775-2.471,3.528-3.287,5.298 c2.49-1.163,5.229-3.906,7.212-5.828c2.094-2.028,5.027-4.716,6.33-7.335c-0.256,1.47-2.07,3.577-3.02,4.809'],
			animDef = { speed : .8, easing : 'ease-in-out' };

		radiobxsFill.forEach(function(el) {
			var svg = createSVGEl();
			var parent = el.parentNode.querySelector('label')
			parent.insertBefore(svg, parent.firstChild);
		});
	}

	function easeInOutQuad(t, b, c, d)  {
    t /= d / 2
    if(t < 1) return c / 2 * t * t + b
    t--
    return -c / 2 * (t * (t - 2) - 1) + b
  }

	function jump(el, options) {
	  var start = window.pageYOffset;

	  var opt = {
	    duration: options.duration,
	    offset: options.offset || 0,
	    callback: options.callback,
	    easing: options.easing || easeInOutQuad
	  };

	  var distance = opt.offset + el.getBoundingClientRect().top;

	  var duration = typeof opt.duration === 'function'
	        ? opt.duration(distance)
	        : opt.duration
	  ;

	  var
	      timeStart = null,
	      timeElapsed
	  ;

	  requestAnimationFrame(loop);

	  function loop(time) {
	      if (timeStart === null)
	          timeStart = time;

	      timeElapsed = time - timeStart;

	      window.scrollTo(0, opt.easing(timeElapsed, start, distance, duration));

	      if (timeElapsed < duration)
	          requestAnimationFrame(loop)
	      else
	          end();
	  }

	  function end() {
	      window.scrollTo(0, start + distance);

	      typeof opt.callback === 'function' && opt.callback();
	      timeStart = null;
	  }

	  // ...

	}

})( window );
